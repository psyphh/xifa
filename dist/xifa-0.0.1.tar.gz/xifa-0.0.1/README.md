# **XIFA**: Accelerated Item Factor Analysis
**XIFA** is a python package for conducting item factor analysis (IFA). 

**XIFA** is build on [**jax**](https://github.com/google/jax). Hence, it can run IFA on GPUs and TPUs to speed up the training process.


