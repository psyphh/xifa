# **XIFA**: Accelerated Item Factor Analysis
**XIFA** is a python package for **accelerated item factor analysis**. **XIFA** is build on [**jax**](https://github.com/google/jax) and hence it can run item factor analysis (IFA) on GPUs and TPUs.


